from PIL import Image, ImageDraw, ImageFont

# Yhali Sheba
# ysheba3@gatech.edu
# I worked on the homework assignment alone, using only this semester's course materials.

# For several of the pictures used, I referred to creative commons images sourced from Google. 
                       
#Helper Function 1
def grayscaleLeftHalf(image):
    pixels = image.load()
    width, height = image.size
    for x in range(width // 2):
        for y in range(height):
            r, g, b = pixels[x, y]
            avg = (r + g + b) // 3
            pixels[x, y] = (avg, avg, avg)
    return image

#Helper Function 2
def channelSwapRightHalf(image):
    pixels = image.load()
    width, height = image.size
    for x in range(width // 2, width):
        for y in range(height):
            r, g, b = pixels[x, y]
            pixels[x, y] = (b, g, r)
    return image

# Helper Function 3 (Text)
def drawText(img, text, position, font, color):
    d = ImageDraw.Draw(img)
    d.text(position, text, font=font, fill=color)
    return img

# Main Function
def imageProject():
    base = Image.open("Tralalero.png")
    canvas = Image.new("RGB", base.size)
    basePx = base.load()
    canvasPx = canvas.load()
    width, height = base.size

    for x in range(width):
        for y in range(height):
            canvasPx[x, y] = basePx[x, y]

    canvas = grayscaleLeftHalf(canvas)
    canvas = channelSwapRightHalf(canvas)

    for x in range(width):
        for y in range(height):
            if x < 10 or x >= width - 10 or y < 10 or y >= height - 10:
                canvasPx[x, y] = (255, 255, 255)

    logo = Image.open("pillow-logo.png")
    lWidth_old, lHeight_old = logo.size

    lWidth_new = int(lWidth_old * 0.2)
    lHeight_new = int(lHeight_old * 0.2)

    scaled_logo = Image.new("RGB", (lWidth_new, lHeight_new))
    logo_px = logo.load()
    scaled_logo_px = scaled_logo.load()

    for x in range(lWidth_new):
        for y in range(lHeight_new):
            x_origin = int(x / 0.2)
            y_origin = int(y / 0.2)
            scaled_logo_px[x, y] = logo_px[x_origin, y_origin]

    chroma_logo_key = logo_px[0, 0]

    for x in range(lWidth_new):
        for y in range(lHeight_new):
            r, g, b = scaled_logo_px[x, y]
            r_key, g_key, b_key = chroma_logo_key[:3]

            r_diff = abs(r - r_key)
            g_diff = abs(g - g_key)
            b_diff = abs(b - b_key)

            if r_diff > 50 or g_diff > 50 or b_diff > 50: #50 is interchangable, seems to do the best job at removing the bg without destroying the logo 
                x_offset = width - lWidth_new
                y_offset = 0

                canvasX = x + x_offset
                canvasY = y + y_offset
                if 0 <= canvasX < width and 0 <= canvasY < height:
                    canvasPx[canvasX, canvasY] = (r, g, b)

    ice = Image.open("Iceking.png")
    icePx = ice.load()
    iWidth, iHeight = ice.size

    for x in range(iWidth):
        for y in range(iHeight):
            r, g, b = icePx[x, y][:3]
            canvasPx[x, y] = (r, g, b)

    chroma_img = Image.open("ChickenJoe.png")
    chroma_w, chroma_h = chroma_img.size
    canvas_w, canvas_h = canvas.size

    chroma_px = chroma_img.load()
    canvas_px = canvas.load()

    x_offset = canvas_w - chroma_w - 10
    y_offset = canvas_h - chroma_h - 10

    r_key, g_key, b_key = chroma_img.getpixel((0, 0))[:3]

    for x in range(chroma_w):
        for y in range(chroma_h):
            r, g, b = chroma_img.getpixel((x, y))[:3]

            r_diff = abs(r - r_key)
            g_diff = abs(g - g_key)
            b_diff = abs(b - b_key)

            if r_diff > 150 or g_diff > 150 or b_diff > 150:
                canvas_x = x + x_offset
                canvas_y = y + y_offset

                if 0 <= canvas_x < canvas_w and 0 <= canvas_y < canvas_h:
                    canvas_px[canvas_x, canvas_y] = (r, g, b)

    font1 = ImageFont.truetype("Cocogoose_trial.otf", size=28)
    font2 = ImageFont.truetype("Fontspring-DEMO-biotif-bolditalic.otf", size=26)

    new_image = canvas

    text1 = "Spring Break 2025"
    text2 = "Yhali Sheba"

    text1_x = (width - len(text1) * 14) // 2
    text2_x = (width - len(text2) * 13) // 2

    new_image = drawText(new_image, text1, (text1_x, 20), font1, (0, 128, 255))
    new_image = drawText(new_image, text2, (text2_x, height - 50), font2, (255, 255, 255))

    return new_image

postcard = imageProject()
postcard.show()
